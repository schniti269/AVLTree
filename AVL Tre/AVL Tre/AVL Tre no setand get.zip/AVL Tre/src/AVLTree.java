
import static java.lang.Math.max;


public class AVLTree<V extends Number & Comparable<V>> {
    public class Node<V> {
        Node<V> Left;
        Node<V> Right;
        V Value;

        public Node(V value) {
            this.Value = value;
            this.Left = null;
            this.Right = null;
        }
    }

    public Node<V> Root;

    public AVLTree(V value) {
        Root = new Node<V>(value);
    }

    public void insert(V value, Node<V> activeNode) {
        int cmp= value.compareTo(activeNode.Value);
        if (cmp<0){
            if(activeNode.Left==null){
                activeNode.Left=new Node<>(value);
            }
            insert(value,activeNode.Left);
        }
        if(cmp>0){
            if(activeNode.Right==null){
                activeNode.Right=new Node<>(value);
            }
            insert(value,activeNode.Right);
        }
        rebalance(Root);
    }
    private int maxDepth(Node n, int Depth){
        if(n==null){
            return Depth;
        }
        return max(maxDepth(n.Left,Depth+1),maxDepth(n.Right,Depth+1));
    }
    private int maxDepth(Node n){
        return maxDepth(n,1);
    }
    private int diff (Node <V> node){
        if(node ==null){
            return 0;
        }
        return maxDepth(node.Left)-maxDepth(node.Right);
    }
    public Node<V> rebalance(Node<V> n) {
        if ( n== null){
            return null;
        }
        int balance = diff(n);
        if (balance > 1) {
            //links zu viel
            rebalance(n.Left.Right);
            return rotateRight(n);
        }
        if (balance < -1) {
            //rechts zu viel
            rebalance(n.Right.Left);
            return rotateLeft(n);
        }
        //alles schon gut
        return n;
    }
    public void rebalanceAll(Node n){
        if(n!= null){
            rebalanceAll(n.Right);
            rebalance(n.Right);
            rebalanceAll(n.Left);
            rebalance(n.Left);
        }

    }



    private Node<V> rotateRight(Node n){
        Node l= n.Left; // ursache für zu viel diff -> root
        Node lr= l.Right; //rechter nachbar von l RECHTE rotation

        l.Right=n;// tauschen
        n.Left=lr;
        return l;
    }
    private Node<V> rotateLeft(Node n){
        Node r= n.Right; // ursache für zu viel diff -> root
        Node rl= r.Left; //Linker nachbar von r LINKE rotation

        r.Left=n;// tauschen
        n.Right=rl;
        return r;
    }
    public void Print(Node n,String indent){
        if (n == null){
            System.out.println(indent+"NAN");
            return;
        }
        Print(n.Left,indent+"   ");
        System.out.println(indent+n.Value);
        Print(n.Right,indent+"   ");


    }
}


